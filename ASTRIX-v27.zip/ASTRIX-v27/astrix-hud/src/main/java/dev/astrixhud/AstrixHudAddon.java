package dev.astrixhud;

import com.mojang.logging.LogUtils;
import dev.astrixhud.hud.CoordsHud;
import dev.astrixhud.hud.InfoHud;
import dev.astrixhud.hud.ModuleListHud;
import dev.astrixhud.hud.TimeHud;
import dev.astrixhud.hud.WatermarkHud;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudGroup;
import org.slf4j.Logger;

public class AstrixHudAddon extends MeteorAddon {
    private static final Logger LOG = LogUtils.getLogger();
    public static final HudGroup GROUP = new HudGroup("Astrix");

    @Override
    public void onInitialize() {
        try {
            Hud hud = Hud.get();
            hud.register(WatermarkHud.INFO);
            hud.register(InfoHud.INFO);
            hud.register(TimeHud.INFO);
            hud.register(CoordsHud.INFO);
            hud.register(ModuleListHud.INFO);
        } catch (Throwable t) {
            LOG.error("Astrix HUD failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.astrixhud";
    }
}
