package dev.astrixhud.hud;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

/** Shared look for every Astrix HUD element: rounded translucent panel + optional rainbow text. */
public abstract class BaseHud extends HudElement {
    protected static final int PAD = 4;

    protected final SettingGroup sgGeneral = settings.getDefaultGroup();
    protected final SettingGroup sgStyle = settings.createGroup("Style");

    protected final Setting<Integer> opacity = sgStyle.add(new IntSetting.Builder()
        .name("opacity")
        .description("Controls the opacity of the HUD background.")
        .defaultValue(60).range(0, 100).sliderRange(0, 100)
        .build());

    protected final Setting<Integer> cornerRadius = sgStyle.add(new IntSetting.Builder()
        .name("corner-radius")
        .description("Controls the roundness of the corners.")
        .defaultValue(3).range(0, 8).sliderRange(0, 8)
        .build());

    protected final Setting<Boolean> rainbow = sgStyle.add(new BoolSetting.Builder()
        .name("rainbow")
        .description("Enables the rainbow colouring effect.")
        .defaultValue(false)
        .build());

    protected final Setting<Double> rainbowSpeed = sgStyle.add(new DoubleSetting.Builder()
        .name("rainbow-speed")
        .description("Speed of the rainbow effect.")
        .defaultValue(1.0).range(0.1, 5.0).sliderRange(0.1, 5.0)
        .visible(rainbow::get)
        .build());

    protected final Setting<SettingColor> primaryColor = sgStyle.add(new ColorSetting.Builder()
        .name("primary-color")
        .description("Main accent colour (used when rainbow is off).")
        .defaultValue(new SettingColor(138, 180, 255, 255))
        .build());

    protected final Setting<SettingColor> secondaryColor = sgStyle.add(new ColorSetting.Builder()
        .name("secondary-color")
        .description("Colour of the normal text.")
        .defaultValue(new SettingColor(255, 255, 255, 255))
        .build());

    protected BaseHud(HudElementInfo<?> info) {
        super(info);
    }

    protected Color accent(int index) {
        if (!rainbow.get()) return primaryColor.get();
        double t = System.currentTimeMillis() / 1000.0 * rainbowSpeed.get();
        double hue = (t * 0.15 + index * 0.04) % 1.0;
        return hsv(hue, 0.75, 1.0);
    }

    protected Color background() {
        return new Color(15, 17, 22, (int) Math.round(opacity.get() * 2.55));
    }

    protected void panel(HudRenderer r, double x, double y, double w, double h) {
        Color c = background();
        int rad = Math.min(cornerRadius.get(), (int) (Math.min(w, h) / 2));
        if (rad <= 0) {
            r.quad(x, y, w, h, c);
            return;
        }
        for (int i = 0; i < rad; i++) {
            double dy = rad - i - 0.5;
            double inset = rad - Math.sqrt(rad * rad - dy * dy);
            r.quad(x + inset, y + i, w - 2 * inset, 1, c);
            r.quad(x + inset, y + h - 1 - i, w - 2 * inset, 1, c);
        }
        r.quad(x, y + rad, w, h - 2 * rad, c);
    }

    private static Color hsv(double h, double s, double v) {
        double hh = (h - Math.floor(h)) * 6.0;
        int i = (int) hh;
        double f = hh - i;
        double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return new Color((int) (r * 255), (int) (g * 255), (int) (b * 255), 255);
    }
}
