package dev.astrixhud.hud;

import dev.astrixhud.AstrixHudAddon;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class CoordsHud extends BaseHud {
    public static final HudElementInfo<CoordsHud> INFO = new HudElementInfo<>(
        AstrixHudAddon.GROUP, "astrix-coords", "Shows the player coordinates.", CoordsHud::new);

    public CoordsHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        String s = mc.player == null
            ? "XYZ: 0 / 0 / 0"
            : "XYZ: " + (int) Math.floor(mc.player.getX()) + " / " + (int) Math.floor(mc.player.getY()) + " / " + (int) Math.floor(mc.player.getZ());
        double w = renderer.textWidth(s, true) + PAD * 2;
        double h = renderer.textHeight(true) + PAD * 2;
        setSize(w, h);
        panel(renderer, x, y, w, h);
        renderer.text(s, x + PAD, y + PAD, secondaryColor.get(), true);
    }
}
