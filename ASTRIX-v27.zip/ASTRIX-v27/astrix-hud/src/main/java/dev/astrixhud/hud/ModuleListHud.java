package dev.astrixhud.hud;

import dev.astrixhud.AstrixHudAddon;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleListHud extends BaseHud {
    public static final HudElementInfo<ModuleListHud> INFO = new HudElementInfo<>(
        AstrixHudAddon.GROUP, "astrix-modules", "Lists the enabled modules.", ModuleListHud::new);

    public enum Sort { Length, Alphabetical, Category }

    private final Setting<Sort> sort = sgGeneral.add(new EnumSetting.Builder<Sort>()
        .name("sort-mode")
        .description("How to sort the module list.")
        .defaultValue(Sort.Length)
        .build());

    public ModuleListHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        List<Row> rows = new ArrayList<>();
        for (Module m : Modules.get().getActive()) rows.add(new Row(m.title, m.category.name));
        if (rows.isEmpty() && isInEditor()) {
            rows.add(new Row("Example Module", "Render"));
            rows.add(new Row("Sprint", "Movement"));
            rows.add(new Row("ESP", "Render"));
        }
        if (rows.isEmpty()) {
            setSize(1, 1);
            return;
        }

        switch (sort.get()) {
            case Length -> rows.sort(Comparator.comparingDouble((Row r) -> renderer.textWidth(r.name, true)).reversed());
            case Alphabetical -> rows.sort(Comparator.comparing((Row r) -> r.name.toLowerCase()));
            case Category -> rows.sort(Comparator.comparing((Row r) -> r.category).thenComparing(r -> r.name.toLowerCase()));
        }

        double rowH = renderer.textHeight(true) + PAD * 2;
        double gap = 2;
        double maxW = 0;
        for (Row r : rows) maxW = Math.max(maxW, renderer.textWidth(r.name, true) + PAD * 2);
        setSize(maxW, rows.size() * (rowH + gap) - gap);

        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            double w = renderer.textWidth(r.name, true) + PAD * 2;
            double rx = x + maxW - w;
            double ry = y + i * (rowH + gap);
            panel(renderer, rx, ry, w, rowH);
            renderer.text(r.name, rx + PAD, ry + PAD, accent(i), true);
        }
    }

    private record Row(String name, String category) {}
}
