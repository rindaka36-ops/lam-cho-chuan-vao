package dev.astrixhud.hud;

import dev.astrixhud.AstrixHudAddon;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;

public class WatermarkHud extends BaseHud {
    public static final HudElementInfo<WatermarkHud> INFO = new HudElementInfo<>(
        AstrixHudAddon.GROUP, "astrix-watermark", "Shows the client name on screen.", WatermarkHud::new);

    private final Setting<String> text = sgGeneral.add(new StringSetting.Builder()
        .name("text")
        .description("Watermark text.")
        .defaultValue("Astrix")
        .build());

    public WatermarkHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        String s = text.get();
        double w = renderer.textWidth(s, true) + PAD * 2;
        double h = renderer.textHeight(true) + PAD * 2;
        setSize(w, h);
        panel(renderer, x, y, w, h);
        renderer.text(s, x + PAD, y + PAD, accent(0), true);
    }
}
