package dev.custommodels.addon.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.entity.PlayerLikeEntity;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class CustomModelsModule extends Module {
    public enum Model {
        CrazyRabbit("Crazy Rabbit"),
        FreddyBear("Freddy Bear"),
        TungTungSahur("Tung Tung Sahur");

        public final String modelName;

        Model(String modelName) {
            this.modelName = modelName;
        }

        @Override
        public String toString() {
            return modelName;
        }
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Model> model = sgGeneral.add(new EnumSetting.Builder<Model>()
        .name("model")
        .description("Model to use.")
        .defaultValue(Model.CrazyRabbit)
        .build());

    public final Setting<Boolean> self = sgGeneral.add(new BoolSetting.Builder()
        .name("self")
        .description("Apply the model to yourself.")
        .defaultValue(true)
        .build());

    public final Setting<Boolean> friends = sgGeneral.add(new BoolSetting.Builder()
        .name("friends")
        .description("Apply the model to your friends.")
        .defaultValue(true)
        .build());

    public CustomModelsModule() {
        super(Categories.Render, "astrix-custom-models", "Replaces player models with custom animated models.");
    }

    public boolean shouldUseCustomModel(PlayerLikeEntity entity) {
        if (!isActive() || entity == null || entity.isSpectator()) return false;
        if (mc.player != null && entity == mc.player) return self.get();
        return friends.get() && Friends.get().get(entity.getName().getString()) != null;
    }

    public String selectedModel() {
        return model.get().modelName;
    }
}
