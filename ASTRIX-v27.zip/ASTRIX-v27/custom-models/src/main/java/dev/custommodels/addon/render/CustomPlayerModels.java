package dev.custommodels.addon.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.ModelCommandRenderer.CrumblingOverlayCommand;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public final class CustomPlayerModels {
    private static final Map<String, Supplier<CustomPlayerModels.CustomModel>> factories =
            new HashMap<>();
    private static final Map<String, CustomPlayerModels.CustomModel> models = new HashMap<>();

    private static ModelPartBuilder cuboid(
            int i, int j, float f, float f1, float f2, float f3, float f4, float f5) {
        return ModelPartBuilder.create().uv(i, j).cuboid(f, f1, f2, f3, f4, f5);
    }

    private static CustomPlayerModels.CustomModel createRabbit() {
        ModelPart modelpart =
                bakeModel(
                        64,
                        64,
                        modelpartdata -> {
                            ModelPartData modelPartData =
                                    modelpartdata.addChild(
                                            "rabbit",
                                            cuboid(
                                                    28, 45, -5.0F, -13.0F, -5.0F, 10.0F, 11.0F,
                                                    8.0F),
                                            ModelTransform.origin(0.0F, 24.0F, 0.0F));
                            modelPartData.addChild(
                                    "right_leg",
                                    cuboid(0, 32, -2.0F, 0.0F, -2.0F, 4.0F, 2.0F, 4.0F),
                                    ModelTransform.origin(-3.0F, -2.0F, -1.0F));
                            modelPartData.addChild(
                                    "left_leg",
                                    cuboid(0, 32, -2.0F, 0.0F, -2.0F, 4.0F, 2.0F, 4.0F),
                                    ModelTransform.origin(3.0F, -2.0F, -1.0F));
                            modelPartData.addChild(
                                    "left_arm",
                                    cuboid(24, 16, 0.0F, 0.0F, -2.0F, 2.0F, 8.0F, 4.0F),
                                    ModelTransform.of(5.0F, -13.0F, -1.0F, 0.0F, 0.0F, -0.0873F));
                            modelPartData.addChild(
                                    "right_arm",
                                    cuboid(24, 16, -2.0F, 0.0F, -2.0F, 2.0F, 8.0F, 4.0F),
                                    ModelTransform.of(-5.0F, -13.0F, -1.0F, 0.0F, 0.0F, 0.0873F));
                            ModelPartData modelPartDataValue =
                                    modelPartData.addChild(
                                            "head",
                                            ModelPartBuilder.create()
                                                    .uv(0, 0)
                                                    .cuboid(-3.0F, 0.0F, -4.0F, 6.0F, 1.0F, 6.0F)
                                                    .uv(0, 45)
                                                    .cuboid(-4.0F, -11.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                                                    .uv(56, 0)
                                                    .cuboid(-5.0F, -9.0F, -5.0F, 2.0F, 3.0F, 2.0F)
                                                    .uv(56, 0)
                                                    .cuboid(3.0F, -9.0F, -5.0F, 2.0F, 3.0F, 2.0F)
                                                    .uv(46, 0)
                                                    .cuboid(1.0F, -20.0F, 0.0F, 3.0F, 9.0F, 1.0F)
                                                    .uv(46, 0)
                                                    .cuboid(-4.0F, -20.0F, 0.0F, 3.0F, 9.0F, 1.0F),
                                            ModelTransform.origin(0.0F, -14.0F, -1.0F));
                            modelPartDataValue.addChild(
                                    "nose",
                                    cuboid(0, 7, -1.5F, -4.0F, -5.5F, 3.0F, 2.0F, 1.0F),
                                    ModelTransform.NONE);
                        });
        return new CustomPlayerModels.CustomModel(
                "Crazy Rabbit",
                Identifier.of("custommodels", "textures/models/rabbit.png"),
                modelpart,
                modelpart.getChild("rabbit"),
                modelpart.getChild("rabbit").getChild("head"),
                modelpart.getChild("rabbit"),
                modelpart.getChild("rabbit").getChild("left_arm"),
                modelpart.getChild("rabbit").getChild("right_arm"),
                modelpart.getChild("rabbit").getChild("left_leg"),
                modelpart.getChild("rabbit").getChild("right_leg")) {
            @Override
            void applyTransform(
                    MatrixStack matrixstack, PlayerEntityRenderState playerentityrenderstate) {
                matrixstack.scale(1.25F, 1.25F, 1.25F);
                matrixstack.translate(0.0F, -0.3F, 0.0F);
            }

            @Override
            void animate(
                    PlayerEntityModel playerentitymodel,
                    PlayerEntityRenderState playerentityrenderstate) {
                this.copyHeadAngles(playerentitymodel);
                this.resetAngles(this.body);
                this.copyLimbAngles(playerentitymodel);
                this.leftArm.roll -= 0.0873F;
                this.rightArm.roll += 0.0873F;
            }
        };
    }

    private static CustomPlayerModels.CustomModel createFreddy() {
        ModelPart modelpart =
                bakeModel(
                        100,
                        80,
                        modelpartdata -> {
                            ModelPartData modelPartData =
                                    modelpartdata.addChild(
                                            "body",
                                            cuboid(0, 0, -1.0F, -14.0F, -1.0F, 2.0F, 24.0F, 2.0F),
                                            ModelTransform.origin(0.0F, -9.0F, 0.0F));
                            modelPartData.addChild(
                                    "torso",
                                    cuboid(8, 0, -6.0F, -9.0F, -4.0F, 12.0F, 18.0F, 8.0F),
                                    ModelTransform.rotation((float) (Math.PI / 180.0), 0.0F, 0.0F));
                            modelPartData.addChild(
                                    "crotch",
                                    cuboid(56, 0, -5.5F, 0.0F, -3.5F, 11.0F, 3.0F, 7.0F),
                                    ModelTransform.origin(0.0F, 9.5F, 0.0F));
                            ModelPartData modelPartDataValue =
                                    modelPartData.addChild(
                                            "head",
                                            cuboid(39, 22, -5.5F, -8.0F, -4.5F, 11.0F, 8.0F, 9.0F),
                                            ModelTransform.origin(0.0F, -13.0F, -0.5F));
                            modelPartDataValue.addChild(
                                    "jaw",
                                    cuboid(49, 65, -5.0F, 0.0F, -4.5F, 10.0F, 3.0F, 9.0F),
                                    ModelTransform.of(0.0F, 0.5F, 0.0F, 0.08726646F, 0.0F, 0.0F));
                            modelPartDataValue.addChild(
                                    "nose",
                                    cuboid(17, 67, -4.0F, -2.0F, -3.0F, 8.0F, 4.0F, 3.0F),
                                    ModelTransform.origin(0.0F, -2.0F, -4.5F));
                            ModelPartData modelPartData2 =
                                    modelPartDataValue.addChild(
                                            "right_ear",
                                            cuboid(8, 0, -1.0F, -3.0F, -0.5F, 2.0F, 3.0F, 1.0F),
                                            ModelTransform.of(
                                                    -4.5F,
                                                    -5.5F,
                                                    0.0F,
                                                    0.05235988F,
                                                    0.0F,
                                                    (float) (-Math.PI / 3)));
                            modelPartData2.addChild(
                                    "right_ear_pad",
                                    cuboid(85, 0, -2.0F, -5.0F, -1.0F, 4.0F, 4.0F, 2.0F),
                                    ModelTransform.origin(0.0F, -1.0F, 0.0F));
                            ModelPartData modelPartData3 =
                                    modelPartDataValue.addChild(
                                            "left_ear",
                                            cuboid(40, 0, -1.0F, -3.0F, -0.5F, 2.0F, 3.0F, 1.0F),
                                            ModelTransform.of(
                                                    4.5F,
                                                    -5.5F,
                                                    0.0F,
                                                    0.05235988F,
                                                    0.0F,
                                                    (float) (Math.PI / 3)));
                            modelPartData3.addChild(
                                    "left_ear_pad",
                                    cuboid(40, 39, -2.0F, -5.0F, -1.0F, 4.0F, 4.0F, 2.0F),
                                    ModelTransform.origin(0.0F, -1.0F, 0.0F));
                            ModelPartData modelPartData4 =
                                    modelPartDataValue.addChild(
                                            "hat",
                                            cuboid(70, 24, -3.0F, -0.5F, -3.0F, 6.0F, 1.0F, 6.0F),
                                            ModelTransform.of(
                                                    0.0F,
                                                    -8.4F,
                                                    0.0F,
                                                    (float) (-Math.PI / 180.0),
                                                    0.0F,
                                                    0.0F));
                            modelPartData4.addChild(
                                    "hat_top",
                                    cuboid(78, 61, -2.0F, -4.0F, -2.0F, 4.0F, 4.0F, 4.0F),
                                    ModelTransform.origin(0.0F, 0.1F, 0.0F));
                            ModelPartData modelPartData5 =
                                    modelPartData.addChild(
                                            "right_arm",
                                            cuboid(48, 0, -1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                                            ModelTransform.of(
                                                    -6.5F,
                                                    -8.0F,
                                                    0.0F,
                                                    0.0F,
                                                    0.0F,
                                                    (float) (Math.PI / 12)));
                            modelPartData5.addChild(
                                    "right_arm_pad",
                                    cuboid(70, 10, -2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            ModelPartData modelPartData6 =
                                    modelPartData5.addChild(
                                            "right_forearm",
                                            cuboid(90, 20, -1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                                            ModelTransform.of(
                                                    0.0F,
                                                    9.6F,
                                                    0.0F,
                                                    (float) (-Math.PI / 18),
                                                    0.0F,
                                                    0.0F));
                            modelPartData6.addChild(
                                    "right_hand",
                                    cuboid(20, 26, -2.0F, 0.0F, -2.5F, 4.0F, 4.0F, 5.0F),
                                    ModelTransform.of(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, -0.05235988F));
                            ModelPartData modelPartData7 =
                                    modelPartData.addChild(
                                            "left_arm",
                                            cuboid(62, 10, -1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                                            ModelTransform.of(
                                                    6.5F,
                                                    -8.0F,
                                                    0.0F,
                                                    0.0F,
                                                    0.0F,
                                                    (float) (-Math.PI / 12)));
                            modelPartData7.addChild(
                                    "left_arm_pad",
                                    cuboid(38, 54, -2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            ModelPartData modelPartData8 =
                                    modelPartData7.addChild(
                                            "left_forearm",
                                            cuboid(90, 48, -1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                                            ModelTransform.of(
                                                    0.0F,
                                                    9.6F,
                                                    0.0F,
                                                    (float) (-Math.PI / 18),
                                                    0.0F,
                                                    0.0F));
                            modelPartData8.addChild(
                                    "left_hand",
                                    cuboid(58, 56, -1.0F, 0.0F, -2.5F, 4.0F, 4.0F, 5.0F),
                                    ModelTransform.of(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.05235988F));
                            ModelPartData modelPartData9 =
                                    modelPartData.addChild(
                                            "right_leg",
                                            cuboid(90, 8, -1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                                            ModelTransform.origin(-3.3F, 12.5F, 0.0F));
                            modelPartData9.addChild(
                                    "right_leg_pad",
                                    cuboid(73, 33, -3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            ModelPartData modelPartData10 =
                                    modelPartData9.addChild(
                                            "right_lower_leg",
                                            cuboid(20, 35, -1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                                            ModelTransform.of(
                                                    0.0F, 9.6F, 0.0F, 0.034906585F, 0.0F, 0.0F));
                            modelPartData10.addChild(
                                    "right_lower_leg_pad",
                                    cuboid(0, 39, -2.5F, 0.0F, -3.0F, 5.0F, 7.0F, 6.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            modelPartData10.addChild(
                                    "right_foot",
                                    cuboid(22, 39, -2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F),
                                    ModelTransform.of(0.0F, 8.0F, 0.0F, -0.034906585F, 0.0F, 0.0F));
                            ModelPartData modelPartData11 =
                                    modelPartData.addChild(
                                            "left_leg",
                                            cuboid(54, 10, -1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                                            ModelTransform.origin(3.3F, 12.5F, 0.0F));
                            modelPartData11.addChild(
                                    "left_leg_pad",
                                    cuboid(48, 39, -3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            ModelPartData modelPartData12 =
                                    modelPartData11.addChild(
                                            "left_lower_leg",
                                            cuboid(72, 48, -1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                                            ModelTransform.of(
                                                    0.0F, 9.6F, 0.0F, 0.034906585F, 0.0F, 0.0F));
                            modelPartData12.addChild(
                                    "left_lower_leg_pad",
                                    cuboid(16, 50, -2.5F, 0.0F, -3.0F, 5.0F, 7.0F, 6.0F),
                                    ModelTransform.origin(0.0F, 0.5F, 0.0F));
                            modelPartData12.addChild(
                                    "left_foot",
                                    cuboid(72, 50, -2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F),
                                    ModelTransform.of(0.0F, 8.0F, 0.0F, -0.034906585F, 0.0F, 0.0F));
                        });
        ModelPart child = modelpart.getChild("body");
        return new CustomPlayerModels.CustomModel(
                "Freddy Bear",
                Identifier.of("custommodels", "textures/models/freddy.png"),
                modelpart,
                child,
                child.getChild("head"),
                child,
                child.getChild("left_arm"),
                child.getChild("right_arm"),
                child.getChild("left_leg"),
                child.getChild("right_leg")) {
            @Override
            void animate(
                    PlayerEntityModel playerentitymodel,
                    PlayerEntityRenderState playerentityrenderstate) {
                this.copyHeadAngles(playerentitymodel);
                this.resetAngles(this.body);
                this.copyLimbAngles(playerentitymodel);
            }

            @Override
            void applyTransform(
                    MatrixStack matrixstack, PlayerEntityRenderState playerentityrenderstate) {
                matrixstack.scale(0.75F, 0.65F, 0.75F);
                matrixstack.translate(0.0F, 0.85F, 0.0F);
            }
        };
    }

    private static CustomPlayerModels.CustomModel getOrCreate(String text, int i) {
        Supplier supplier = factories.get(text);
        if (supplier == null) {
            return null;
        } else {
            if (models.size() > 128) {
                models.clear();
            }

            return models.computeIfAbsent(
                    text + "#" + i, textValue -> (CustomPlayerModels.CustomModel) supplier.get());
        }
    }

    private static ModelPartBuilder cuboid(
            int i, int j, float f, float f1, float f2, float f3, float f4, float f5, float f6) {
        return ModelPartBuilder.create().uv(i, j).cuboid(f, f1, f2, f3, f4, f5, new Dilation(f6));
    }

    private static ModelPart bakeModel(int i, int j, Consumer<ModelPartData> consumer) {
        ModelData modeldata = new ModelData();
        consumer.accept(modeldata.getRoot());
        return TexturedModelData.of(modeldata, i, j).createModel();
    }

    private CustomPlayerModels() {}

    static {
        factories.put("Crazy Rabbit", CustomPlayerModels::createRabbit);
        factories.put("Freddy Bear", CustomPlayerModels::createFreddy);
        factories.put("Tung Tung Sahur", CustomPlayerModels::createTung);
    }

    private static CustomPlayerModels.CustomModel createTung() {
        ModelPart modelpart =
                bakeModel(
                        64,
                        64,
                        modelpartdata -> {
                            ModelPartData modelPartData =
                                    modelpartdata.addChild(
                                            "tung",
                                            ModelPartBuilder.create(),
                                            ModelTransform.origin(0.0F, 24.0F, 0.0F));
                            ModelPartData modelPartDataValue =
                                    modelPartData.addChild(
                                            "chest",
                                            ModelPartBuilder.create(),
                                            ModelTransform.origin(0.0F, -11.0F, 1.0F));
                            modelPartDataValue.addChild(
                                    "body",
                                    cuboid(0, 18, -3.0F, -5.5F, -2.5F, 6.0F, 11.0F, 5.0F, 0.3F),
                                    ModelTransform.origin(0.0F, -5.5F, 0.0F));
                            ModelPartData modelPartData2 =
                                    modelPartDataValue.addChild(
                                            "head",
                                            ModelPartBuilder.create()
                                                    .uv(0, 0)
                                                    .cuboid(
                                                            -3.5F,
                                                            -11.17242F,
                                                            -2.89262F,
                                                            7.0F,
                                                            12.0F,
                                                            6.0F,
                                                            new Dilation(0.15F))
                                                    .uv(35, 4)
                                                    .cuboid(
                                                            -3.45F,
                                                            -7.67242F,
                                                            -2.99262F,
                                                            2.0F,
                                                            2.0F,
                                                            0.9F,
                                                            new Dilation(0.5F))
                                                    .uv(35, 4)
                                                    .mirrored()
                                                    .cuboid(
                                                            1.45F,
                                                            -7.67242F,
                                                            -2.99262F,
                                                            2.0F,
                                                            2.0F,
                                                            0.9F,
                                                            new Dilation(0.5F))
                                                    .mirrored(false)
                                                    .uv(36, 29)
                                                    .cuboid(
                                                            -4.1F, -8.42242F, -3.69262F, 3.25F,
                                                            0.5F, 2.25F)
                                                    .uv(36, 29)
                                                    .cuboid(
                                                            0.85F, -8.42242F, -3.69262F, 3.25F,
                                                            0.5F, 2.25F),
                                            ModelTransform.origin(0.0F, -12.12758F, -0.10738F));
                            modelPartData2.addChild(
                                    "nose",
                                    cuboid(30, 24, -1.0F, -2.5F, -1.0F, 1.5F, 5.0F, 2.0F, 0.15F),
                                    ModelTransform.of(
                                            0.25F,
                                            -5.67242F,
                                            -2.64262F,
                                            (float) (Math.PI / 9),
                                            0.0F,
                                            0.0F));
                            modelPartData2.addChild(
                                    "brow_left",
                                    cuboid(30, 31, -1.5F, -0.5F, -1.0F, 3.0F, 1.0F, 2.0F),
                                    ModelTransform.origin(-2.25F, -9.27242F, -2.64262F));
                            modelPartData2.addChild(
                                    "brow_right",
                                    cuboid(30, 31, -1.5F, -0.5F, -1.0F, 3.0F, 1.0F, 2.0F),
                                    ModelTransform.origin(2.25F, -9.27242F, -2.64262F));
                            modelPartData2.addChild(
                                    "eye_left",
                                    cuboid(6, 34, -0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F, 0.4F),
                                    ModelTransform.origin(-2.35F, -5.97242F, -2.69262F));
                            modelPartData2.addChild(
                                    "eye_right",
                                    cuboid(6, 34, -0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F, 0.4F),
                                    ModelTransform.origin(2.35F, -5.97242F, -2.69262F));
                            ModelPartData modelPartData3 =
                                    modelPartDataValue.addChild(
                                            "left_arm",
                                            cuboid(
                                                    26, 0, 0.25F, 5.15F, -1.0F, 2.0F, 5.0F, 2.0F,
                                                    0.1F),
                                            ModelTransform.origin(3.75F, -10.35F, 0.0F));
                            modelPartData3.addChild(
                                    "left_arm_top",
                                    cuboid(22, 24, -1.0F, -3.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                                    ModelTransform.of(
                                            0.75F,
                                            2.35F,
                                            0.0F,
                                            0.0F,
                                            0.0F,
                                            (float) (Math.PI / 18)));
                            ModelPartData modelPartData4 =
                                    modelPartDataValue.addChild(
                                            "right_arm",
                                            cuboid(
                                                    26, 0, -2.25F, 5.15F, -1.0F, 2.0F, 5.0F, 2.0F,
                                                    0.1F),
                                            ModelTransform.origin(-3.75F, -10.35F, 0.0F));
                            modelPartData4.addChild(
                                    "right_arm_top",
                                    cuboid(22, 24, -1.0F, -3.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                                    ModelTransform.of(
                                            -0.75F,
                                            2.35F,
                                            0.0F,
                                            0.0F,
                                            0.0F,
                                            (float) (-Math.PI / 18)));
                            modelPartData4.addChild(
                                    "bat",
                                    cuboid(34, 6, 0.0F, -1.0F, -1.0F, 12.0F, 2.0F, 2.0F),
                                    ModelTransform.of(
                                            -1.25F,
                                            9.1F,
                                            0.1F,
                                            (float) (-Math.PI / 2),
                                            1.134464F,
                                            (float) (-Math.PI / 2)));
                            modelPartData.addChild(
                                    "left_leg",
                                    ModelPartBuilder.create()
                                            .uv(26, 7)
                                            .cuboid(
                                                    -1.0F,
                                                    0.0F,
                                                    -1.0F,
                                                    2.0F,
                                                    4.0F,
                                                    2.0F,
                                                    new Dilation(0.15F))
                                            .uv(22, 32)
                                            .cuboid(
                                                    -1.0F,
                                                    3.0F,
                                                    -1.0F,
                                                    2.0F,
                                                    2.0F,
                                                    2.0F,
                                                    new Dilation(0.3F))
                                            .uv(26, 0)
                                            .cuboid(-1.0F, 4.0F, -1.0F, 2.0F, 5.0F, 2.0F)
                                            .uv(22, 18)
                                            .cuboid(-1.5F, 9.0F, -3.0F, 3.0F, 2.0F, 4.0F),
                                    ModelTransform.origin(2.0F, -11.0F, 1.0F));
                            modelPartData.addChild(
                                    "right_leg",
                                    ModelPartBuilder.create()
                                            .uv(26, 7)
                                            .cuboid(
                                                    -1.0F,
                                                    0.0F,
                                                    -1.0F,
                                                    2.0F,
                                                    4.0F,
                                                    2.0F,
                                                    new Dilation(0.15F))
                                            .uv(22, 32)
                                            .cuboid(
                                                    -1.0F,
                                                    3.0F,
                                                    -1.0F,
                                                    2.0F,
                                                    2.0F,
                                                    2.0F,
                                                    new Dilation(0.3F))
                                            .uv(26, 0)
                                            .cuboid(-1.0F, 4.0F, -1.0F, 2.0F, 5.0F, 2.0F)
                                            .uv(22, 18)
                                            .cuboid(-1.5F, 9.0F, -3.0F, 3.0F, 2.0F, 4.0F),
                                    ModelTransform.origin(-2.0F, -11.0F, 1.0F));
                        });
        ModelPart child = modelpart.getChild("tung");
        ModelPart childValue = child.getChild("chest");
        return new CustomPlayerModels.CustomModel(
                "Tung Tung Sahur",
                Identifier.of("custommodels", "textures/models/tung.png"),
                modelpart,
                child,
                childValue.getChild("head"),
                childValue,
                childValue.getChild("left_arm"),
                childValue.getChild("right_arm"),
                child.getChild("left_leg"),
                child.getChild("right_leg"));
    }

    public static boolean render(
            String text,
            PlayerEntityModel playerentitymodel,
            PlayerEntityRenderState playerentityrenderstate,
            MatrixStack matrixstack,
            OrderedRenderCommandQueue orderedrendercommandqueue,
            int i,
            int j,
            int k,
            int l) {
        CustomPlayerModels.CustomModel customModel = getOrCreate(text, playerentityrenderstate.id);
        if (customModel == null) {
            return false;
        } else {
            try {
                // 1.21.9+ defers the vanilla model's animation until the command queue is
                // flushed, so at submit time its limb angles can be stale. Animate it now.
                playerentitymodel.setAngles(playerentityrenderstate);
                customModel.animate(playerentitymodel, playerentityrenderstate);
            } catch (Throwable ignored) {
                // keep going with whatever angles the model has
            }
            matrixstack.push();
            try {
                customModel.applyTransform(matrixstack, playerentityrenderstate);
                RenderLayer renderlayer = RenderLayers.entityTranslucent(customModel.texture);
                orderedrendercommandqueue.submitModelPart(
                        customModel.root,
                        matrixstack,
                        renderlayer,
                        i,
                        j,
                        (Sprite) null,
                        false,
                        false,
                        k,
                        (CrumblingOverlayCommand) null,
                        l);
            } catch (Throwable t) {
                // never leave a half-drawn custom model: fall back to the vanilla model
                matrixstack.pop();
                return false;
            }
            matrixstack.pop();
            return true;
        }
    }

    @Environment(EnvType.CLIENT)
    private static class CustomModel {
        protected final ModelPart root;
        protected final ModelPart rightLeg;
        protected final ModelPart head;
        protected final ModelPart rightArm;
        protected final String name;
        protected final ModelPart leftArm;
        protected final ModelPart body;
        protected final Identifier texture;
        protected final ModelPart poseRoot;
        protected final ModelPart leftLeg;

        protected CustomModel(
                String stringValue,
                Identifier identifier,
                ModelPart modelpart,
                ModelPart modelPart7Value,
                ModelPart modelPart3Value,
                ModelPart modelPart6Value,
                ModelPart modelPart5Value,
                ModelPart modelPart4Value,
                ModelPart modelPart8Value,
                ModelPart modelPart2Value) {
            this.name = stringValue;
            this.texture = identifier;
            this.root = modelpart;
            this.poseRoot = modelPart7Value;
            this.head = modelPart3Value;
            this.body = modelPart6Value;
            this.leftArm = modelPart5Value;
            this.rightArm = modelPart4Value;
            this.leftLeg = modelPart8Value;
            this.rightLeg = modelPart2Value;
        }

        protected void copyLimbAngles(PlayerEntityModel playerentitymodel) {
            this.leftArm.pitch = playerentitymodel.leftArm.pitch;
            this.leftArm.yaw = playerentitymodel.leftArm.yaw;
            this.leftArm.roll = playerentitymodel.leftArm.roll;
            this.rightArm.pitch = playerentitymodel.rightArm.pitch;
            this.rightArm.yaw = playerentitymodel.rightArm.yaw;
            this.rightArm.roll = playerentitymodel.rightArm.roll;
            this.leftLeg.pitch = playerentitymodel.leftLeg.pitch;
            this.leftLeg.yaw = playerentitymodel.leftLeg.yaw;
            this.leftLeg.roll = playerentitymodel.leftLeg.roll;
            this.rightLeg.pitch = playerentitymodel.rightLeg.pitch;
            this.rightLeg.yaw = playerentitymodel.rightLeg.yaw;
            this.rightLeg.roll = playerentitymodel.rightLeg.roll;
        }

        protected void copyBodyAngles(PlayerEntityModel playerentitymodel) {
            this.body.pitch = playerentitymodel.body.pitch;
            this.body.yaw = playerentitymodel.body.yaw;
            this.body.roll = playerentitymodel.body.roll;
        }

        protected void resetAngles(ModelPart modelpart) {
            modelpart.pitch = 0.0F;
            modelpart.yaw = 0.0F;
            modelpart.roll = 0.0F;
        }

        protected void copyHeadAngles(PlayerEntityModel playerentitymodel) {
            this.head.pitch = playerentitymodel.head.pitch;
            this.head.yaw = playerentitymodel.head.yaw;
            this.head.roll = playerentitymodel.head.roll;
        }

        void animate(
                PlayerEntityModel playerentitymodel,
                PlayerEntityRenderState playerentityrenderstate) {
            this.copyHeadAngles(playerentitymodel);
            this.copyBodyAngles(playerentitymodel);
            this.copyLimbAngles(playerentitymodel);
        }

        void applyTransform(
                MatrixStack matrixstack, PlayerEntityRenderState playerentityrenderstate) {}
    }
}
