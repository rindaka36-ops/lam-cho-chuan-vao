package dev.spodebug.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;

import java.util.*;

/**
 * Port of Mental Debug "player-debug": client-side diagnostics overlay.
 * Shows player counts (world vs tab list), nearby players, loaded chunks and top packets.
 * Useful to spot players that are in the tab list but not loaded (out of render distance).
 */
public class PlayerDebug extends Module {
    public enum Sort { Distance, Name, Id }

    /** One scanned player. */
    private record Row(String name, String uuid, int entityId, double x, double y, double z,
                       double distance, double horizontal, boolean alive, float health, int armor, boolean inRange) {}

    private static final class PacketStat {
        int count;
        long first;
        long last;
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgShow = settings.createGroup("Show");
    private final SettingGroup sgStyle = settings.createGroup("Style");

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range").description("Players within this range count as in range.")
            .defaultValue(256.0).min(32.0).max(512.0).sliderRange(32, 512).build());
    private final Setting<Boolean> ignoreSelf = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-self").defaultValue(true).build());
    private final Setting<String> nameFilter = sgGeneral.add(new StringSetting.Builder()
            .name("name-filter").description("Only list players whose name contains this text.")
            .defaultValue("").build());
    private final Setting<Sort> sort = sgGeneral.add(new EnumSetting.Builder<Sort>()
            .name("sort").defaultValue(Sort.Distance).build());
    private final Setting<Integer> maxPlayers = sgGeneral.add(new IntSetting.Builder()
            .name("max-players").defaultValue(8).min(1).sliderRange(1, 30).build());

    private final Setting<Boolean> showCounts = sgShow.add(new BoolSetting.Builder().name("show-counts").defaultValue(true).build());
    private final Setting<Boolean> showPlayers = sgShow.add(new BoolSetting.Builder().name("show-players").defaultValue(true).build());
    private final Setting<Boolean> showDistances = sgShow.add(new BoolSetting.Builder().name("show-distances").defaultValue(true).build());
    private final Setting<Boolean> showUuid = sgShow.add(new BoolSetting.Builder().name("show-uuid").defaultValue(false).build());
    private final Setting<Boolean> showIds = sgShow.add(new BoolSetting.Builder().name("show-entity-ids").defaultValue(false).build());
    private final Setting<Boolean> showChunks = sgShow.add(new BoolSetting.Builder().name("show-chunks").defaultValue(true).build());
    private final Setting<Boolean> showPackets = sgShow.add(new BoolSetting.Builder().name("show-packets").defaultValue(false).build());

    private final Setting<SettingColor> textColor = sgStyle.add(new ColorSetting.Builder()
            .name("text-color").defaultValue(new SettingColor(255, 255, 255, 255)).build());
    private final Setting<SettingColor> accentColor = sgStyle.add(new ColorSetting.Builder()
            .name("accent-color").defaultValue(new SettingColor(255, 220, 0, 255)).build());
    private final Setting<SettingColor> bgColor = sgStyle.add(new ColorSetting.Builder()
            .name("background-color").defaultValue(new SettingColor(0, 0, 0, 120)).build());
    private final Setting<Double> scale = sgStyle.add(new DoubleSetting.Builder()
            .name("scale").defaultValue(1.0).min(0.5).max(2.5).sliderRange(0.5, 2.5).build());
    private final Setting<Integer> posX = sgStyle.add(new IntSetting.Builder()
            .name("x").defaultValue(8).sliderRange(0, 1000).build());
    private final Setting<Integer> posY = sgStyle.add(new IntSetting.Builder()
            .name("y").defaultValue(20).sliderRange(0, 600).build());

    private final List<Row> rows = new ArrayList<>();
    private final Map<String, PacketStat> packets = new HashMap<>();
    private final List<String> tabOnly = new ArrayList<>();
    private int worldCount, tabCount, matched;
    private int loaded, inView, outsideView, chunkX, chunkZ;
    private int tick;

    public PlayerDebug(Category category) {
        super(category, "astrix-player-debug", "Diagnoses client-side players, tab list, chunks, and packet counts.");
    }

    @Override
    public void onActivate() {
        packets.clear();
        rows.clear();
        tick = 0;
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!showPackets.get()) return;
        long now = System.currentTimeMillis();
        PacketStat s = packets.computeIfAbsent(event.packet.getClass().getSimpleName(), k -> {
            PacketStat st = new PacketStat();
            st.first = now;
            return st;
        });
        s.count++;
        s.last = now;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;
        if (++tick % 10 != 0) return;
        scanPlayers();
        compareTab();
        scanChunks();
    }

    private void scanPlayers() {
        rows.clear();
        String filter = nameFilter.get().toLowerCase(Locale.ROOT);
        double r = range.get();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (ignoreSelf.get() && p == mc.player) continue;
            String name = p.getName().getString();
            if (!filter.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(filter)) continue;
            double dx = p.getX() - mc.player.getX();
            double dy = p.getY() - mc.player.getY();
            double dz = p.getZ() - mc.player.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            rows.add(new Row(name, p.getUuid().toString(), p.getId(), p.getX(), p.getY(), p.getZ(),
                    distance, horizontal, p.isAlive(), p.getHealth(), p.getArmor(), distance <= r));
        }
        Comparator<Row> cmp = switch (sort.get()) {
            case Name -> Comparator.comparing(Row::name, String.CASE_INSENSITIVE_ORDER);
            case Id -> Comparator.comparingInt(Row::entityId);
            default -> Comparator.comparingDouble(Row::distance);
        };
        rows.sort(cmp);
    }

    /** World players vs tab list: tab-only = players listed but not loaded around you. */
    private void compareTab() {
        tabOnly.clear();
        worldCount = mc.world.getPlayers().size();
        tabCount = 0;
        matched = 0;
        if (mc.getNetworkHandler() == null) return;
        Set<String> worldNames = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) worldNames.add(p.getName().getString());
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            tabCount++;
            String n = e.getProfile().name();
            if (worldNames.contains(n)) matched++;
            else tabOnly.add(n);
        }
    }

    private void scanChunks() {
        chunkX = mc.player.getChunkPos().x;
        chunkZ = mc.player.getChunkPos().z;
        int view = mc.options.getClampedViewDistance();
        loaded = mc.world.getChunkManager().getLoadedChunkCount();
        int in = 0;
        for (int dx = -view; dx <= view; dx++) {
            for (int dz = -view; dz <= view; dz++) {
                if (mc.world.getChunkManager().getWorldChunk(chunkX + dx, chunkZ + dz, false) != null) in++;
            }
        }
        inView = in;
        outsideView = Math.max(0, loaded - in);
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (mc.player == null || mc.world == null) return;
        int text = textColor.get().getPacked();
        int accent = accentColor.get().getPacked();

        List<String> lines = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        lines.add("PLAYER DEBUG"); cols.add(accent);

        if (showCounts.get()) {
            lines.add(String.format("World %d | Tab %d | Match %d", worldCount, tabCount, matched)); cols.add(text);
            if (!tabOnly.isEmpty()) {
                String names = String.join(", ", tabOnly.subList(0, Math.min(5, tabOnly.size())));
                lines.add("Tab only (" + tabOnly.size() + "): " + names); cols.add(accent);
            }
        }
        if (showPlayers.get()) {
            lines.add("NEARBY"); cols.add(accent);
            int shown = 0;
            for (Row r : rows) {
                if (shown++ >= maxPlayers.get()) break;
                StringBuilder sb = new StringBuilder(r.name());
                if (showDistances.get()) sb.append(String.format("  %.1fm", r.distance()));
                if (showIds.get()) sb.append("  #").append(r.entityId());
                sb.append(String.format("  hp %.0f  ar %d", r.health(), r.armor()));
                if (!r.inRange()) sb.append("  (far)");
                lines.add(sb.toString()); cols.add(r.alive() ? text : accent);
                if (showUuid.get()) { lines.add("  " + r.uuid()); cols.add(text); }
            }
            if (rows.isEmpty()) { lines.add("none"); cols.add(text); }
        }
        if (showChunks.get()) {
            lines.add(String.format("Chunk %d,%d | loaded %d | in view %d | outside %d",
                    chunkX, chunkZ, loaded, inView, outsideView)); cols.add(text);
        }
        if (showPackets.get()) {
            lines.add("PACKETS (top 5)"); cols.add(accent);
            List<Map.Entry<String, PacketStat>> top = new ArrayList<>(packets.entrySet());
            top.sort((a, b) -> Integer.compare(b.getValue().count, a.getValue().count));
            for (int i = 0; i < Math.min(5, top.size()); i++) {
                PacketStat s = top.get(i).getValue();
                double secs = Math.max(1.0, (s.last - s.first) / 1000.0);
                lines.add(String.format("%s  %d  (%.1f/s)", top.get(i).getKey(), s.count, s.count / secs)); cols.add(text);
            }
        }

        DrawContext ctx = event.drawContext;
        float sc = scale.get().floatValue();
        int width = 0;
        for (String l : lines) width = Math.max(width, mc.textRenderer.getWidth(l));
        int lineH = 11;
        int w = width + 10;
        int h = lines.size() * lineH + 8;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        int x = (int) (posX.get() / sc), y = (int) (posY.get() / sc);
        ctx.fill(x, y, x + w, y + h, bgColor.get().getPacked());
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawText(mc.textRenderer, lines.get(i), x + 5, y + 4 + i * lineH, cols.get(i), false);
        }
        ctx.getMatrices().popMatrix();
    }
}
