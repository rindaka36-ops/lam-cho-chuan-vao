package dev.spodebug.modules;

import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.ChunkPos;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Spo Debug: mob-cluster chunk detector (rewrite of Spooky Chunk).
 * Finds chunks with lots of mobs and groups of mobs standing close together
 * (typical for spawners / mob farms), then highlights, tracers, notifies and logs them.
 */
public class SpoDebug extends Module {
    private static final Logger LOG = LogUtils.getLogger();
    private static final int MAX_MOBS = 600; // safety cap for the O(n^2) clustering

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgFilter = settings.createGroup("Mob Filter");
    private final SettingGroup sgAlerts = settings.createGroup("Alerts");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // ---- General ----
    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("range").description("Max distance (blocks) to consider mobs.")
            .defaultValue(128).min(16).sliderRange(16, 256).build());
    private final Setting<Integer> minMobs = sgGeneral.add(new IntSetting.Builder()
            .name("min-mobs-per-chunk").description("Mobs in one chunk needed to flag it.")
            .defaultValue(8).min(1).sliderRange(1, 64).build());
    private final Setting<Double> clusterRadius = sgGeneral.add(new DoubleSetting.Builder()
            .name("cluster-radius").description("Mobs closer than this (blocks) belong to the same cluster.")
            .defaultValue(6.0).min(1).sliderRange(1, 24).build());
    private final Setting<Integer> clusterMin = sgGeneral.add(new IntSetting.Builder()
            .name("cluster-min-mobs").description("Mobs needed in a cluster to flag its chunk(s).")
            .defaultValue(5).min(2).sliderRange(2, 40).build());
    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
            .name("scan-interval").description("Ticks between scans.")
            .defaultValue(10).min(1).sliderRange(1, 100).build());
    private final Setting<Boolean> skipNamed = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-named").description("Ignore mobs with a name tag (pets, farm animals).")
            .defaultValue(true).build());

    // ---- Mob filter ----
    private final Setting<Boolean> useFilter = sgFilter.add(new BoolSetting.Builder()
            .name("filter-by-type").description("Only count the mob types selected below.")
            .defaultValue(true).build());
    private final Setting<Set<EntityType<?>>> mobTypes = sgFilter.add(new EntityTypeListSetting.Builder()
            .name("mob-types").description("Mob types counted when the filter is on.")
            .defaultValue(Set.of(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
                    EntityType.CAVE_SPIDER, EntityType.BLAZE, EntityType.SILVERFISH, EntityType.CREEPER))
            .visible(useFilter::get).build());

    // ---- Alerts ----
    private final Setting<Boolean> chat = sgAlerts.add(new BoolSetting.Builder()
            .name("chat-notify").description("Chat message for each new flagged chunk.")
            .defaultValue(true).build());
    private final Setting<Boolean> sound = sgAlerts.add(new BoolSetting.Builder()
            .name("sound").description("Play a sound for each new flagged chunk.")
            .defaultValue(true).build());
    private final Setting<Integer> cooldown = sgAlerts.add(new IntSetting.Builder()
            .name("cooldown-seconds").description("Seconds before the same chunk can alert again.")
            .defaultValue(60).min(1).sliderRange(5, 600).build());
    private final Setting<Boolean> logFile = sgAlerts.add(new BoolSetting.Builder()
            .name("log-to-file").description("Append coordinates to <game dir>/spo-debug-log.txt.")
            .defaultValue(false).build());

    // ---- Render ----
    private final Setting<SettingColor> fillColor = sgRender.add(new ColorSetting.Builder()
            .name("fill-color").defaultValue(new SettingColor(255, 132, 32, 70)).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
            .name("line-color").defaultValue(new SettingColor(255, 132, 32, 200)).build());
    private final Setting<Integer> renderY = sgRender.add(new IntSetting.Builder()
            .name("render-y").defaultValue(63).sliderRange(-64, 320).build());
    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
            .name("tracers").description("Draw a line to each cluster center.")
            .defaultValue(true).build());
    private final Setting<SettingColor> tracerColor = sgRender.add(new ColorSetting.Builder()
            .name("tracer-color").defaultValue(new SettingColor(255, 200, 60, 200))
            .visible(tracers::get).build());

    /** A group of nearby mobs. */
    private record Cluster(double x, double y, double z, int size) {}

    private volatile Set<ChunkPos> flaggedChunks = Collections.emptySet();
    private volatile List<Cluster> clusters = Collections.emptyList();
    private final Map<ChunkPos, Long> lastAlert = new HashMap<>();
    private int tickCount;

    public SpoDebug(Category category) {
        super(category, "astrix-spo-debug", "Finds chunks with many mobs / mob clusters (spawners, farms).");
    }

    @Override
    public void onActivate() {
        flaggedChunks = Collections.emptySet();
        clusters = Collections.emptyList();
        lastAlert.clear();
        tickCount = 0;
    }

    @Override
    public void onDeactivate() {
        flaggedChunks = Collections.emptySet();
        clusters = Collections.emptyList();
        lastAlert.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) return;
        if (++tickCount % interval.get() != 0) return;

        double maxDistSq = (double) range.get() * range.get();
        List<Entity> mobs = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof MobEntity) || !e.isAlive()) continue;
            if (e.squaredDistanceTo(mc.player) > maxDistSq) continue;
            if (skipNamed.get() && e.hasCustomName()) continue;
            if (useFilter.get() && !mobTypes.get().contains(e.getType())) continue;
            mobs.add(e);
            if (mobs.size() >= MAX_MOBS) break;
        }

        // 1) per-chunk counts
        Map<ChunkPos, Integer> perChunk = new HashMap<>();
        for (Entity e : mobs) perChunk.merge(e.getChunkPos(), 1, Integer::sum);

        Set<ChunkPos> flagged = new HashSet<>();
        int need = minMobs.get();
        for (Map.Entry<ChunkPos, Integer> en : perChunk.entrySet()) {
            if (en.getValue() >= need) flagged.add(en.getKey());
        }

        // 2) clusters (union-find on distance)
        int n = mobs.size();
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;
        double rSq = clusterRadius.get() * clusterRadius.get();
        for (int i = 0; i < n; i++) {
            Entity a = mobs.get(i);
            for (int j = i + 1; j < n; j++) {
                if (a.squaredDistanceTo(mobs.get(j)) <= rSq) union(parent, i, j);
            }
        }
        Map<Integer, List<Entity>> groups = new HashMap<>();
        for (int i = 0; i < n; i++) groups.computeIfAbsent(find(parent, i), k -> new ArrayList<>()).add(mobs.get(i));

        List<Cluster> found = new ArrayList<>();
        int cMin = clusterMin.get();
        for (List<Entity> g : groups.values()) {
            if (g.size() < cMin) continue;
            double sx = 0, sy = 0, sz = 0;
            for (Entity e : g) {
                sx += e.getX();
                sy += e.getY();
                sz += e.getZ();
                flagged.add(e.getChunkPos());
            }
            found.add(new Cluster(sx / g.size(), sy / g.size(), sz / g.size(), g.size()));
        }

        flaggedChunks = Collections.unmodifiableSet(flagged);
        clusters = Collections.unmodifiableList(found);

        // 3) alerts with per-chunk cooldown
        long now = System.currentTimeMillis();
        long cdMs = cooldown.get() * 1000L;
        for (ChunkPos cp : flagged) {
            Long last = lastAlert.get(cp);
            if (last != null && now - last < cdMs) continue;
            lastAlert.put(cp, now);
            int count = perChunk.getOrDefault(cp, 0);
            alert(cp, count);
        }
        lastAlert.values().removeIf(t -> now - t > cdMs * 4);
    }

    private void alert(ChunkPos cp, int count) {
        int bx = cp.getStartX() + 8, bz = cp.getStartZ() + 8;
        if (chat.get()) info("Mob signal: chunk (%d, %d) at XZ %d %d, %d mobs.", cp.x, cp.z, bx, bz, count);
        if (sound.get() && mc.player != null) {
            mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.2F, 0.8F);
        }
        if (logFile.get()) writeLog(cp, bx, bz, count);
    }

    private void writeLog(ChunkPos cp, int bx, int bz, int count) {
        try {
            Path file = FabricLoader.getInstance().getGameDir().resolve("spo-debug-log.txt");
            String line = String.format("[%s] chunk %d,%d  XZ %d %d  mobs %d  dim %s%n",
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    cp.x, cp.z, bx, bz, count,
                    mc.world != null ? mc.world.getRegistryKey().getValue() : "?");
            Files.writeString(file, line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            LOG.error("Spo Debug: failed to write log", e);
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null) return;
        Set<ChunkPos> chunks = flaggedChunks;
        List<Cluster> cl = clusters;
        if (chunks.isEmpty() && cl.isEmpty()) return;

        SettingColor f = fillColor.get();
        SettingColor l = lineColor.get();
        Color fill = new Color(f.r, f.g, f.b, f.a);
        Color line = new Color(l.r, l.g, l.b, l.a);
        double y = renderY.get();
        for (ChunkPos c : chunks) {
            double x = c.getStartX(), z = c.getStartZ();
            event.renderer.box(x, y, z, x + 16.0, y + 0.1, z + 16.0, fill, line, ShapeMode.Both, 0);
        }

        if (tracers.get()) {
            SettingColor t = tracerColor.get();
            Color tracer = new Color(t.r, t.g, t.b, t.a);
            for (Cluster c : cl) {
                event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                        c.x(), c.y(), c.z(), tracer);
            }
        }
    }

    private static int find(int[] p, int i) {
        while (p[i] != i) {
            p[i] = p[p[i]];
            i = p[i];
        }
        return i;
    }

    private static void union(int[] p, int a, int b) {
        int ra = find(p, a), rb = find(p, b);
        if (ra != rb) p[ra] = rb;
    }

    @Override
    public String getInfoString() {
        int c = flaggedChunks.size();
        return c == 0 ? null : String.valueOf(c);
    }
}
