package com.astrix.debug;

import meteordevelopment.meteorclient.systems.modules.Category;
import net.minecraft.class_1802;

public class AstrixCategory {
    public static final Category CATEGORY = new Category("Astrix Finder", class_1802.field_27063.method_7854());
    public static final Category MISC_V2 = new Category("Astrix Extra", class_1802.field_8895.method_7854());
}

