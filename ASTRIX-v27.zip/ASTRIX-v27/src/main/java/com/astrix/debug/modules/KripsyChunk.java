package com.astrix.debug.modules;

import com.astrix.debug.AstrixCategory;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;      // ChunkPos
import net.minecraft.class_2246;      // Blocks
import net.minecraft.class_2350;      // Direction
import net.minecraft.class_2680;      // BlockState
import net.minecraft.class_2741;      // Properties
import net.minecraft.class_2818;      // WorldChunk
import net.minecraft.class_2826;      // ChunkSection

/**
 * Kripsy Chunk (ex KrispyChunkFinder): flags chunks that look like a player base.
 *
 *  - >= min-vines vines in Y vine-min-y..vine-max-y          (default 55, Y 16..60)
 *  - >= min-deepslate rotated deepslate (axis != Y) in Y ..  (default 1,  Y 0..60)
 *
 * Scans on the client thread with a per-tick time budget, caches the result per chunk,
 * checks vines first (cheap) and only then deepslate, and walks blocks y -> z -> x.
 */
public class KripsyChunk
extends Module {
    private record ScanEntry(class_2818 chunk, int scannedAtTick, boolean hit) {
    }

    private final SettingGroup sgScan;
    private final SettingGroup sgRender;
    private final Setting<Integer> radiusSetting;
    private final Setting<Integer> minVines;
    private final Setting<Integer> vineMinY;
    private final Setting<Integer> vineMaxY;
    private final Setting<Integer> minDeepslate;
    private final Setting<Integer> deepslateMinY;
    private final Setting<Integer> deepslateMaxY;
    private final Setting<Integer> rescanTicks;
    private final Setting<Double> budgetMs;
    private final Setting<Boolean> chatNotify;
    private final Setting<Boolean> renderFilledChunk;
    private final Setting<SettingColor> chunkFillColor;
    private final Setting<SettingColor> chunkLineColor;
    private final Setting<Double> planeY;
    private final Setting<SettingColor> fillColor;
    private final Setting<SettingColor> lineColor;

    private final Map<class_1923, ScanEntry> cache = new HashMap<class_1923, ScanEntry>();
    private final Set<class_1923> hits = ConcurrentHashMap.newKeySet();
    private final ArrayDeque<class_1923> pending = new ArrayDeque<class_1923>();
    private Object lastWorld = null;
    private int tickCount = 0;

    public KripsyChunk() {
        super(AstrixCategory.CATEGORY, "astrix-kripsy-chunk", "Flags chunks with many vines + rotated deepslate (player base sign).");
        this.sgScan = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("Render");

        this.radiusSetting = this.sgScan.add(new IntSetting.Builder()
            .name("radius").description("Scan radius in chunks (capped by your render distance + 2).")
            .defaultValue(10).min(1).sliderMax(25).build());
        this.minVines = this.sgScan.add(new IntSetting.Builder()
            .name("min-vines").description("Minimum vines in the chunk.")
            .defaultValue(55).min(1).sliderMax(200).build());
        this.vineMinY = this.sgScan.add(new IntSetting.Builder()
            .name("vine-min-y").description("Lowest Y counted for vines.")
            .defaultValue(16).sliderRange(-64, 320).build());
        this.vineMaxY = this.sgScan.add(new IntSetting.Builder()
            .name("vine-max-y").description("Highest Y counted for vines.")
            .defaultValue(60).sliderRange(-64, 320).build());
        this.minDeepslate = this.sgScan.add(new IntSetting.Builder()
            .name("min-rotated-deepslate").description("Minimum deepslate placed sideways (axis X/Z).")
            .defaultValue(1).min(1).sliderMax(20).build());
        this.deepslateMinY = this.sgScan.add(new IntSetting.Builder()
            .name("deepslate-min-y").description("Lowest Y counted for deepslate.")
            .defaultValue(0).sliderRange(-64, 320).build());
        this.deepslateMaxY = this.sgScan.add(new IntSetting.Builder()
            .name("deepslate-max-y").description("Highest Y counted for deepslate.")
            .defaultValue(60).sliderRange(-64, 320).build());
        this.rescanTicks = this.sgScan.add(new IntSetting.Builder()
            .name("rescan-ticks").description("Rescan an already scanned chunk after this many ticks (20 = 1s).")
            .defaultValue(1200).min(20).sliderMax(6000).build());
        this.budgetMs = this.sgScan.add(new DoubleSetting.Builder()
            .name("scan-budget-ms").description("Max milliseconds spent scanning per tick.")
            .defaultValue(2.0).min(0.5).sliderMax(10.0).build());
        this.chatNotify = this.sgScan.add(new BoolSetting.Builder()
            .name("chat-notify").description("Send a chat message when a new chunk is flagged.")
            .defaultValue(true).build());

        this.renderFilledChunk = this.sgRender.add(new BoolSetting.Builder()
            .name("render-filled-chunk").description("Fill the whole flagged chunk (full height).")
            .defaultValue(false).build());
        this.chunkFillColor = this.sgRender.add(new ColorSetting.Builder()
            .name("chunk-fill-color").defaultValue(new SettingColor(0, 255, 0, 40)).build());
        this.chunkLineColor = this.sgRender.add(new ColorSetting.Builder()
            .name("chunk-line-color").defaultValue(new SettingColor(0, 255, 0, 255)).build());
        this.planeY = this.sgRender.add(new DoubleSetting.Builder()
            .name("plane-y").description("Y of the flat marker plane.")
            .defaultValue(63.0).sliderRange(-64.0, 320.0).build());
        this.fillColor = this.sgRender.add(new ColorSetting.Builder()
            .name("fill-color").defaultValue(new SettingColor(0, 255, 0, 80)).build());
        this.lineColor = this.sgRender.add(new ColorSetting.Builder()
            .name("line-color").defaultValue(new SettingColor(0, 255, 0, 180)).build());
    }

    public void onActivate() {
        this.reset();
    }

    public void onDeactivate() {
        this.reset();
    }

    private void reset() {
        this.cache.clear();
        this.hits.clear();
        this.pending.clear();
        this.lastWorld = null;
        this.tickCount = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        // World / dimension changed -> drop everything
        if (this.mc.field_1687 != this.lastWorld) {
            this.reset();
            this.lastWorld = this.mc.field_1687;
        }
        class_1923 center = this.mc.field_1724.method_31476();
        if (this.tickCount++ % 10 == 0) {
            this.rebuildPending(center);
        }
        this.drainPending();
    }

    private int computeRadius() {
        int view = this.mc.field_1690 == null ? 8 : (Integer)this.mc.field_1690.method_42503().method_41753();
        return Math.max(1, Math.min(this.radiusSetting.get(), view + 2));
    }

    private static boolean isFar(class_1923 c, class_1923 center, int limit) {
        return Math.abs(c.field_9181 - center.field_9181) > limit || Math.abs(c.field_9180 - center.field_9180) > limit;
    }

    /** Queue chunks that are new / replaced / stale, nearest to the player first. */
    private void rebuildPending(class_1923 center) {
        int r = this.computeRadius();
        this.cache.keySet().removeIf(c -> KripsyChunk.isFar(c, center, r + 2));
        this.hits.removeIf(c -> KripsyChunk.isFar(c, center, r + 2));
        this.pending.clear();

        int rescan = this.rescanTicks.get();
        List<class_1923> todo = new ArrayList<class_1923>();
        for (int dx = -r; dx <= r; ++dx) {
            for (int dz = -r; dz <= r; ++dz) {
                class_1923 cp = new class_1923(center.field_9181 + dx, center.field_9180 + dz);
                class_2818 wc = this.mc.field_1687.method_8497(cp.field_9181, cp.field_9180);
                if (wc == null || wc.method_12223()) {
                    this.cache.remove(cp);
                    this.hits.remove(cp);
                    continue;
                }
                ScanEntry e = this.cache.get(cp);
                if (e != null && e.chunk() == wc && this.tickCount - e.scannedAtTick() < rescan) continue;
                todo.add(cp);
            }
        }
        todo.sort(Comparator.comparingInt(c -> {
            int dx = c.field_9181 - center.field_9181;
            int dz = c.field_9180 - center.field_9180;
            return dx * dx + dz * dz;
        }));
        this.pending.addAll(todo);
    }

    /** Scan queued chunks until this tick's time budget is used up. */
    private void drainPending() {
        if (this.pending.isEmpty()) {
            return;
        }
        long deadline = System.nanoTime() + (long)(this.budgetMs.get() * 1_000_000.0);
        while (!this.pending.isEmpty()) {
            class_1923 cp = this.pending.pollFirst();
            class_2818 wc = this.mc.field_1687.method_8497(cp.field_9181, cp.field_9180);
            if (wc == null || wc.method_12223()) {
                this.cache.remove(cp);
                this.hits.remove(cp);
                continue;
            }
            boolean hit;
            try {
                hit = this.isBaseChunk(wc);
            }
            catch (RuntimeException ex) {
                hit = false; // broken chunk: cache as "no" so it is not rescanned every tick
            }
            this.cache.put(cp, new ScanEntry(wc, this.tickCount, hit));
            if (hit) {
                if (this.hits.add(cp) && this.chatNotify.get().booleanValue()) {
                    ChatUtils.info("Kripsy Chunk: base chunk at X" + (cp.field_9181 << 4) + " Z" + (cp.field_9180 << 4)
                        + " (chunk " + cp.field_9181 + ", " + cp.field_9180 + ")", new Object[0]);
                }
            } else {
                this.hits.remove(cp);
            }
            if (System.nanoTime() >= deadline) break;
        }
    }

    private boolean isBaseChunk(class_2818 chunk) {
        // Vines are cheap and rule out almost every chunk -> check first
        if (this.countVines(chunk) < this.minVines.get()) {
            return false;
        }
        return this.countRotatedDeepslate(chunk) >= this.minDeepslate.get();
    }

    private int countVines(class_2818 chunk) {
        int count = 0;
        int need = this.minVines.get();
        int fromY = this.vineMinY.get();
        int toY = this.vineMaxY.get();
        class_2826[] sections = chunk.method_12006();
        int minY = chunk.method_31607();
        for (int si = 0; si < sections.length; ++si) {
            int sectionBottomY = minY + si * 16;
            int lyFrom = Math.max(0, fromY - sectionBottomY);
            int lyTo = Math.min(15, toY - sectionBottomY);
            if (lyFrom > lyTo) continue;
            class_2826 section = sections[si];
            if (section == null || section.method_38292()) continue;
            if (!section.method_19523(s -> s.method_27852(class_2246.field_10597))) continue;
            for (int ly = lyFrom; ly <= lyTo; ++ly) {
                for (int lz = 0; lz < 16; ++lz) {
                    for (int lx = 0; lx < 16; ++lx) {
                        if (!section.method_12254(lx, ly, lz).method_27852(class_2246.field_10597)) continue;
                        if (++count >= need) {
                            return count;
                        }
                    }
                }
            }
        }
        return count;
    }

    private int countRotatedDeepslate(class_2818 chunk) {
        int count = 0;
        int need = this.minDeepslate.get();
        int fromY = this.deepslateMinY.get();
        int toY = this.deepslateMaxY.get();
        class_2826[] sections = chunk.method_12006();
        int minY = chunk.method_31607();
        for (int si = 0; si < sections.length; ++si) {
            int sectionBottomY = minY + si * 16;
            int lyFrom = Math.max(0, fromY - sectionBottomY);
            int lyTo = Math.min(15, toY - sectionBottomY);
            if (lyFrom > lyTo) continue;
            class_2826 section = sections[si];
            if (section == null || section.method_38292()) continue;
            if (!section.method_19523(s -> s.method_27852(class_2246.field_28888))) continue;
            for (int ly = lyFrom; ly <= lyTo; ++ly) {
                for (int lz = 0; lz < 16; ++lz) {
                    for (int lx = 0; lx < 16; ++lx) {
                        class_2680 state = section.method_12254(lx, ly, lz);
                        if (!state.method_27852(class_2246.field_28888)
                            || !state.method_28498(class_2741.field_12496)
                            || state.method_11654(class_2741.field_12496) == class_2350.class_2351.field_11052) continue;
                        if (++count >= need) {
                            return count;
                        }
                    }
                }
            }
        }
        return count;
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (this.mc.field_1687 == null || this.hits.isEmpty()) {
            return;
        }
        double y1 = this.planeY.get();
        double y2 = y1 + 0.1;
        double minY = this.mc.field_1687.method_31607();
        double maxY = minY + this.mc.field_1687.method_31605();
        for (class_1923 c : this.hits) {
            double x1 = c.method_8326();
            double z1 = c.method_8328();
            if (this.renderFilledChunk.get().booleanValue()) {
                event.renderer.box(x1, minY, z1, x1 + 16.0, maxY, z1 + 16.0, (Color)this.chunkFillColor.get(), (Color)this.chunkLineColor.get(), ShapeMode.Both, 0);
            }
            event.renderer.box(x1, y1, z1, x1 + 16.0, y2, z1 + 16.0, (Color)this.fillColor.get(), (Color)this.lineColor.get(), ShapeMode.Both, 0);
        }
    }
}
